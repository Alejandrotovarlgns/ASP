﻿using System;

namespace Ejercicio_Excepciones_1
{
    class Program
    {
        static void Main()
        {
            while (true)
            {
                Console.Write("Ingresa un número: ");
                string input = Console.ReadLine();

                if (!int.TryParse(input, out int numero))
                {
                    Console.WriteLine("Valor no válido");
                    continue;
                }

                try
                {
                    if (numero < 0)
                        throw new Exception("El número no puede ser negativo");

                    Console.WriteLine($"Número aceptado: {numero}");
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }
        }
    }
}
