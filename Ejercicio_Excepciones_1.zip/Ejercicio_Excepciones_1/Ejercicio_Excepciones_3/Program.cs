﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ejercicio_Excepciones_3
{
    class Program
    {
        static void Main()
        {
            List<string> palabras = new List<string> { "A", "B", "C", "D", "E" };

            Console.Write("Ingresa índice: ");
            string input = Console.ReadLine();

            if (!int.TryParse(input, out int indice))
            {
                Console.WriteLine("Índice no válido");
                return;
            }

            string palabra = palabras.ElementAtOrDefault(indice);

            if (palabra == null)
                Console.WriteLine("Índice fuera de rango");
            else
                Console.WriteLine($"Palabra: \"{palabra}\"");
        }
    }
}
