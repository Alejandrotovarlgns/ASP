﻿using System;

namespace Ejercicio_9
{
    class Producto
    {
        public string Nombre { get; set; }
        public double Precio { get; set; }

        public Producto(string nombre, double precio)
        {
            Nombre = nombre;
            Precio = precio;
        }

        public void Datos()
        {
            Console.WriteLine($"{Nombre} - {Precio}€");
        }
    }

    class Program
    {
        static void Main()
        {
            Producto[] productos = new Producto[3];

            for (int i = 0; i < 3; i++)
            {
                Console.Write($"Nombre producto {i + 1}: ");
                string nombre = Console.ReadLine();

                Console.Write($"Precio producto {i + 1}: ");
                double precio = double.Parse(Console.ReadLine());

                productos[i] = new Producto(nombre, precio);
            }

            double total = 0;
            Console.WriteLine("\nProductos comprados:");
            foreach (var p in productos)
            {
                p.Datos();
                total += p.Precio;
            }

            Console.WriteLine($"Total de la compra: {total}€");
        }
    }
}
