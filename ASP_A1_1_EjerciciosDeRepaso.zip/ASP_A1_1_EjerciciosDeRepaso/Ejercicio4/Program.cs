﻿using System;

namespace Ejercicio_4
{
    class Program
    {
        static void Main()
        {
            Console.Write("Introduce el primer número: ");
            int num1 = int.Parse(Console.ReadLine());

            Console.Write("Introduce el segundo número: ");
            int num2 = int.Parse(Console.ReadLine());

            if (num1 > num2)
                Console.WriteLine("El primer número es mayor");
            else if (num2 > num1)
                Console.WriteLine("El segundo número es mayor");
            else
                Console.WriteLine("Los números son iguales");
        }
    }
}
