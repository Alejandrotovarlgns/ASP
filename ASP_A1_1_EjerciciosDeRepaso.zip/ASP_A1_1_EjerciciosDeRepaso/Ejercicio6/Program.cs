﻿using System;

namespace Ejercicio_6
{
    class Program
    {
        static void Main()
        {
            Console.Write("Introduce un número: ");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine(num % 2 == 0 ? "El número es par" : "El número es impar");
        }
    }
}
