﻿using System;
using System.Collections.Generic;

namespace Ejercicio_10
{
    class Producto
    {
        public string Nombre { get; set; }
        public double Precio { get; set; }

        public Producto(string nombre, double precio)
        {
            Nombre = nombre;
            Precio = precio;
        }

        public void Datos()
        {
            Console.WriteLine($"{Nombre} - {Precio}€");
        }
    }

    class Program
    {
        static void Main()
        {
            List<Producto> productos = new List<Producto>();

            Console.WriteLine("Introduce 3 productos:");
            for (int i = 0; i < 3; i++)
            {
                Console.Write($"Nombre producto {i + 1}: ");
                string nombre = Console.ReadLine();

                Console.Write($"Precio producto {i + 1}: ");
                double precio = double.Parse(Console.ReadLine());

                productos.Add(new Producto(nombre, precio));
            }

            double total = 0;
            Console.WriteLine("\nLista de productos:");
            foreach (var p in productos)
            {
                p.Datos();
                total += p.Precio;
            }

            double descuento = total * 0.15;
            double totalConDescuento = total - descuento;

            Console.WriteLine($"\nTotal sin descuento: {total}€");
            Console.WriteLine($"Descuento 15%: {descuento}€");
            Console.WriteLine($"Total con descuento: {totalConDescuento}€");
        }
    }
}
