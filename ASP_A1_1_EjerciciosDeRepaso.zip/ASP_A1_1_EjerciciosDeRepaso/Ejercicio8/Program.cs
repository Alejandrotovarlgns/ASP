﻿using System;

namespace Ejercicio_8
{
    class Producto
    {
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public double Precio { get; set; }

        public Producto(string nombre, string descripcion, double precio)
        {
            Nombre = nombre;
            Descripcion = descripcion;
            Precio = precio;
        }

        public void Datos()
        {
            Console.WriteLine($"Nombre: {Nombre}");
            Console.WriteLine($"Descripción: {Descripcion}");
            Console.WriteLine($"Precio: {Precio}€");
            Console.WriteLine("---------------------------");
        }
    }

    class Program
    {
        static void Main()
        {
            Producto p1 = new Producto("Camiseta", "Camiseta de algodón", 15.5);
            Producto p2 = new Producto("Zapatos", "Zapatos deportivos", 45.0);
            Producto p3 = new Producto("Gorra", "Gorra de béisbol", 10.0);

            p1.Datos();
            p2.Datos();
            p3.Datos();
        }
    }
}
