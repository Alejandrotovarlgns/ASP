﻿using System;

namespace Ejercicio_1
{
    class Program
    {
        static void Main()
        {
            Console.Write("Introduce el primer número: ");
            double num1 = double.Parse(Console.ReadLine());

            Console.Write("Introduce el segundo número: ");
            double num2 = double.Parse(Console.ReadLine());

            Console.WriteLine($"Suma: {num1 + num2}");
            Console.WriteLine($"Resta: {num1 - num2}");
            Console.WriteLine($"Multiplicación: {num1 * num2}");
            Console.WriteLine(num2 != 0 ? $"División: {num1 / num2}" : "División: No se puede dividir entre 0");
        }
    }
}
