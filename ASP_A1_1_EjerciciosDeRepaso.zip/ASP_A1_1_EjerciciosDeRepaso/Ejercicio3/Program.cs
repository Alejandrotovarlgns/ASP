﻿using System;

namespace Ejercicio_3
{
    class Program
    {
        static void Main()
        {
            Console.Write("Introduce tu edad en años: ");
            int edad = int.Parse(Console.ReadLine());
            int meses = edad * 12;
            Console.WriteLine($"Has vivido {meses} meses.");
        }
    }
}
