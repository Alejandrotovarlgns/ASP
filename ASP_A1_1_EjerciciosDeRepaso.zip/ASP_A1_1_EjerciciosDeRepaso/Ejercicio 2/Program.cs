﻿using System;

namespace Ejercicio_2
{
    class Program
    {
        static void Main()
        {
            Console.Write("Introduce tu nombre: ");
            string nombre = Console.ReadLine();
            Console.WriteLine($"Hola, {nombre}, bienvenido al programa");
        }
    }
}
