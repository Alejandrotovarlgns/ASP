﻿using System;
using System.Collections.Generic;

namespace Ejercicio_11
{
    class Producto
    {
        public string Nombre { get; set; }
        public string Descripcion { get; set; }

        private double precio;
        public double Precio
        {
            get { return precio; }
            set
            {
                if (value < 0)
                    precio = 0;
                else
                    precio = value;
            }
        }

        public Producto(string nombre, string descripcion, double precio)
        {
            Nombre = nombre;
            Descripcion = descripcion;
            Precio = precio;
        }

        public virtual void Datos()
        {
            Console.WriteLine($"Nombre: {Nombre}");
            Console.WriteLine($"Descripción: {Descripcion}");
            Console.WriteLine($"Precio: {Precio}€");
        }
    }

    class ProductoDetallado : Producto
    {
        private Dictionary<string, string> caracteristicas = new Dictionary<string, string>();

        public string this[string key]
        {
            get => caracteristicas.ContainsKey(key) ? caracteristicas[key] : "No definido";
            set => caracteristicas[key] = value;
        }

        public ProductoDetallado(string nombre, string descripcion, double precio)
            : base(nombre, descripcion, precio) { }

        public override void Datos()
        {
            base.Datos();
            Console.WriteLine("Características:");
            foreach (var c in caracteristicas)
            {
                Console.WriteLine($"{c.Key}: {c.Value}");
            }
            Console.WriteLine("---------------------------");
        }
    }

    class Program
    {
        static void Main()
        {
            ProductoDetallado p1 = new ProductoDetallado("Laptop", "Portátil 16GB RAM", 1200);
            p1["Peso"] = "1.5 Kg";
            p1["Color"] = "Negro";

            ProductoDetallado p2 = new ProductoDetallado("Smartphone", "Pantalla OLED", 800);
            p2["Peso"] = "180 g";
            p2["Batería"] = "4000 mAh";

            p1.Datos();
            p2.Datos();
        }
    }
}
