﻿using System;

namespace Ejercicio_7
{
    class Program
    {
        static void Main()
        {
            Console.Write("Introduce tu nombre: ");
            string nombre = Console.ReadLine();

            Console.Write("Tiempo carrera 1 (segundos): ");
            double t1 = double.Parse(Console.ReadLine());

            Console.Write("Tiempo carrera 2 (segundos): ");
            double t2 = double.Parse(Console.ReadLine());

            Console.Write("Tiempo carrera 3 (segundos): ");
            double t3 = double.Parse(Console.ReadLine());

            double promedio = CalcularPromedio(t1, t2, t3);
            Console.WriteLine($"Hola, {nombre}, tu tiempo medio es: {promedio} segundos");
        }

        static double CalcularPromedio(double a, double b, double c)
        {
            return (a + b + c) / 3;
        }
    }
}
