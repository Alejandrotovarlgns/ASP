﻿using System;

namespace Ejercicio_5
{
    class Program
    {
        static void Main()
        {
            Console.Write("Introduce tu nota: ");
            double nota = double.Parse(Console.ReadLine());

            Console.WriteLine(nota >= 5 ? "Aprobado" : "Suspendido");
        }
    }
}
